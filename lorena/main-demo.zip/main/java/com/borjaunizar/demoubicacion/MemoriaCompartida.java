package com.borjaunizar.demoubicacion;

public class MemoriaCompartida {

    static String channel_id = "";
    static String phoneOther = "";
    static String nameOther = "";

    public static void setChannel(String ch){
        channel_id = ch;
    }

    public static String getChannel(){
        return channel_id;
    }

    public static void setPhone(String phone){
        phoneOther = phone;
    }

    public static String getPhone(){
        return phoneOther;
    }

    public static void setUser(String usr){
        nameOther = usr;
    }

    public static String getUser(){
        return nameOther;
    }


}
