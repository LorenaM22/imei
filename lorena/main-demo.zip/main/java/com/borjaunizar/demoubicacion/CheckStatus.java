package com.borjaunizar.demoubicacion;

public class CheckStatus{

    static boolean registered = false;
    static boolean loggedin = false;

    public static boolean checkRegStatus(){
        return registered;
    }

    public static boolean checkLogStatus(){
        return loggedin;
    }

    public static void setLogStatus(boolean stat){
        loggedin = stat;
    }

    public static void setRegStatus(boolean stat){
        registered = stat;
    }
}
