package com.borjaunizar.demoubicacion;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.vishnusivadas.advanced_httpurlconnection.PutData;

import java.util.ArrayList;

public class RegisterActivity extends AppCompatActivity {

    private TextInputEditText usernameR, passR, tlfR, chR;
    private int typeValue = 0;
    private Spinner usertype;
    private Button register, login;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        usernameR = findViewById(R.id.usernameR);
        passR = findViewById(R.id.passR);
        tlfR = findViewById(R.id.tlf);
        chR = findViewById(R.id.chid);

        usertype = findViewById(R.id.usertype);

        register = findViewById(R.id.buttonR);
        login = findViewById(R.id.buttonL);

        ArrayList<String> types = new ArrayList<String>();
        types.add("Tipo de Registro");
        types.add("Usuario");
        types.add("Contacto");

        ArrayAdapter adp = new ArrayAdapter(RegisterActivity.this, android.R.layout.simple_spinner_dropdown_item, types);

        usertype.setAdapter(adp);
        usertype.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String type = (String) usertype.getAdapter().getItem(position);

                if(type.equals("Usuario")) typeValue = 1;
                else if (type.equals("Contacto")) typeValue = 2;

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckStatus.setRegStatus(true);
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String username, password, tlf, ch, type;
                username = String.valueOf(usernameR.getText());
                password = String.valueOf(passR.getText());
                tlf = String.valueOf(tlfR.getText());
                ch = String.valueOf(chR.getText());
                type = String.valueOf(typeValue);


                if(!username.equals("") && !password.equals("") && !tlf.equals("") && !ch.equals("") && !type.equals("0")){
                    Handler handler = new Handler();
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            String[] field = new String[5];
                            field[0] = "username";
                            field[1] = "password";
                            field[2] = "tlf";
                            field[3] = "ch";
                            field[4] = "type";
                            String[] data = new String[5];
                            data[0] = username;
                            data[1] = password;
                            data[2] = tlf;
                            data[3] = ch;
                            data[4] = type;

                            PutData putData = new PutData("http://192.168.86.244/loginregister/signup.php","POST", field, data);
                            if(putData.startPut()){
                                if(putData.onComplete()){
                                    String result = putData.getResult();
                                    if(result.equals("Sign Up Success")){
                                        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                                        startActivity(intent);
                                        finish();
                                    }
                                    else {
                                        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        }
                    });

                }
                else {
                    Toast.makeText(getApplicationContext(),"Rellena todos los campos",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }



}
