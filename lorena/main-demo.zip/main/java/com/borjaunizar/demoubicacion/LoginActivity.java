package com.borjaunizar.demoubicacion;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;
import com.vishnusivadas.advanced_httpurlconnection.PutData;

import com.borjaunizar.demoubicacion.CheckStatus.*;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText usernameIn, passIn;
    private Button login, reg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameIn = findViewById(R.id.username);
        passIn = findViewById(R.id.pass);
        login = findViewById(R.id.buttonlog);
        reg = findViewById(R.id.buttonreg);

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), RegisterActivity.class);
                startActivity(intent);
                finish();
            }
        });


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String username, password;
                username = String.valueOf(usernameIn.getText());
                password = String.valueOf(passIn.getText());


                if(!username.equals("") && !password.equals("")){
                    Handler handler = new Handler();
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            String[] field = new String[2];
                            field[0] = "username";
                            field[1] = "password";
                            String[] data = new String[2];
                            data[0] = username;
                            data[1] = password;

                            PutData putData = new PutData("http://192.168.86.244/loginregister/login.php","POST", field, data);
                            if(putData.startPut()){
                                if(putData.onComplete()){
                                    String result = putData.getResult();
                                    if(result.equals("Login Success 1")){ // Usuario
                                        getOtherData();
                                        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(getApplicationContext(), InterActivity.class);
                                        startActivity(intent);
                                        finish();
                                    }
                                    else if(result.equals("Login Success 2")){ // Contacto
                                        getOtherData();
                                        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(getApplicationContext(), ContactActivity.class);
                                        startActivity(intent);
                                        finish();
                                    }
                                    else {
                                        Toast.makeText(getApplicationContext(),result,Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        }
                    });

                }
                else {
                    Toast.makeText(getApplicationContext(),"Rellena ambos campos",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void getOtherData(){
        final String username;
        username = String.valueOf(usernameIn.getText());

        if(!username.equals("")){
            Handler handler = new Handler();
            handler.post(new Runnable() {
                @Override
                public void run() {
                    String[] field = new String[1];
                    field[0] = "username";
                    String[] data = new String[1];
                    data[0] = username;

                    PutData putData = new PutData("http://192.168.86.244/loginregister/getch.php","POST", field, data);
                    if(putData.startPut()){
                        if(putData.onComplete()){
                            String result = putData.getResult();
                            String [] resultV = result.split(" ");
                            MemoriaCompartida.setChannel(resultV[0]);
                            MemoriaCompartida.setUser(resultV[1]);
                            MemoriaCompartida.setPhone(resultV[2]);
                        }
                    }
                }
            });

        }
    }

}

