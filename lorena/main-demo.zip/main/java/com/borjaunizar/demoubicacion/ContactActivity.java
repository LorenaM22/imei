package com.borjaunizar.demoubicacion;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.scaledrone.lib.Listener;
import com.scaledrone.lib.Room;
import com.scaledrone.lib.RoomListener;
import com.scaledrone.lib.Scaledrone;

import java.util.Locale;
import java.util.Random;

public class ContactActivity extends AppCompatActivity implements
        RoomListener,OnMapReadyCallback {

    //para la sala de chat de scaledrone
    private String channelID = MemoriaCompartida.getChannel();
    private String roomName = "observable-room";
    private Scaledrone scaledrone;
    private MessageAdapter messageAdapter;
    private ListView messagesView;

    //para el arbol de decisiones
    private arbol tree ;
    private final MemberData contacto = new MemberData("contacto", "blue");
    private final MemberData data = new MemberData("usuario", "blue");
    private String inicio="null";

    //para la ubicacion en el mapa
    private double Latitud=41.65606;
    private double Longitud=-0.87734;
    private GoogleMap mMap;

    //para los datos del contacto
    TextView datos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        // This is where we write the mesage

        messageAdapter = new MessageAdapter(this);
        messagesView = (ListView) findViewById(R.id.messages_view);
        messagesView.setAdapter(messageAdapter);

        datos=(TextView) findViewById(R.id.datos);
        datos.setText(MemoriaCompartida.getUser()+" "+MemoriaCompartida.getPhone());

        //para la ubicacion en el mapa
        int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable((getApplicationContext()));

        if (status== ConnectionResult.SUCCESS){
            SupportMapFragment mapFragment=(SupportMapFragment)getSupportFragmentManager().findFragmentById((R.id.map));
            mapFragment.getMapAsync(this);
        }
        else{
            Dialog dialog=GooglePlayServicesUtil.getErrorDialog(status, (Activity)getApplicationContext(),10);
        }

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


        //para la sala de chat en scaledrone
        scaledrone = new Scaledrone(channelID, data);
        scaledrone.connect(new Listener() {
            @Override
            public void onOpen() {
                System.out.println("Scaledrone connection open");
                // Since the MainActivity itself already implement RoomListener we can pass it as a target
                scaledrone.subscribe(roomName, ContactActivity.this);
            }

            @Override
            public void onOpenFailure(Exception ex) {
                System.err.println(ex);
            }

            @Override
            public void onFailure(Exception ex) {
                System.err.println(ex);
            }

            @Override
            public void onClosed(String reason) {
                System.err.println(reason);
            }
        });

        //para el arbol de decisiones
        tree=new  arbol();
        inicio=tree.play("inicio");
        final Message message_ini = new Message(inicio, data, true);

        messageAdapter.add(message_ini);
        messagesView.setSelection(messagesView.getCount() - 1);

    }

    // Successfully connected to Scaledrone room
    @Override
    public void onOpen(Room room) {
        System.out.println("Conneted to room");
    }

    // Connecting to Scaledrone room failed
    @Override
    public void onOpenFailure(Room room, Exception ex) {
        System.err.println(ex);
    }


    //para la recepcion de un mensaje en la sala del chat
    @Override
    public void onMessage(Room room, com.scaledrone.lib.Message receivedMessage) {
        final ObjectMapper mapper = new ObjectMapper();

        boolean belongsToCurrentUser = receivedMessage.getClientID().equals(scaledrone.getClientID());
        final Message message = new Message(receivedMessage.getData().asText(), data, belongsToCurrentUser);
        final Message message_send = new Message(receivedMessage.getData().asText(), data, belongsToCurrentUser);

        //determinar la respuesta del arbol segun lo recibido
        String pregunta=tree.play(message.getText());
        final Message message2 = new Message(pregunta, data, true);

        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                //mostrar mensajes por pantalla si no son la ubicacion
                if(!receivedMessage.getData().asText().contains("Latitud")) {
                    messageAdapter.add(message_send);
                    messagesView.setSelection(messagesView.getCount() - 1);

                    messageAdapter.add(message2);
                    messagesView.setSelection(messagesView.getCount() - 1);
                }
                else{//pintar la ubicacion en el mapa
                    String[] split_ubi=message.getText().split("\n");
                    Latitud= Double.parseDouble(split_ubi[0].split(":")[1]);

                    LatLng location = new LatLng(Latitud, Longitud);
                    mMap.addMarker(new MarkerOptions().position(location).title(split_ubi[4].split(":")[1]));
                    mMap.moveCamera(CameraUpdateFactory.newLatLng(location));
                }

            }

        });
    }

    //para la ubicacion en el mapa
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        UiSettings uiSettings=mMap.getUiSettings();
        uiSettings.setZoomControlsEnabled(true);

        // Add a marker in Sydney and move the camera
        LatLng ini = new LatLng(Latitud, Longitud);
        mMap.addMarker(new MarkerOptions().position(ini).title("Titulo marcador"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(ini));
    }

}
class MemberData {
    private String name;
    private String color;

    public MemberData(String name, String color) {
        this.name = name;
        this.color = color;
    }

    // Add an empty constructor so we can later parse JSON into MemberData using Jackson
    public MemberData() {
    }

    public String getName() {
        return name;
    }

    public String getColor() {
        return color;
    }
}